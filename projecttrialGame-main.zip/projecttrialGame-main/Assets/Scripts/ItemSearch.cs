using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TakaraSearch : MonoBehaviour
{
    // Start is called before the first frame update
    public static int PriceSum = 0;
    ProjectTrial trial;
    [SerializeField] GameObject player;
    [SerializeField] AudioClip audioClip;
    AudioSource source;
    SpriteRenderer sp;
    PolygonCollider2D col;
    void Start()
    {
        PriceSum = 0;
        trial = new ProjectTrial();
        trial.Enable();
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    private void OnTriggerStay2D(Collider2D other)
    {
        if(other.gameObject.CompareTag("takara"))
        {
            Debug.Log("��ڐG");
            if(trial.UI.ItemGet.IsPressed())
            {
                Destroy(other.gameObject);
                PriceSum += other.gameObject.GetComponent<TakaraPrice>().price;
                Debug.Log(PriceSum);
            }
        }
        if(other.gameObject.CompareTag("ChangeItems"))//�ϐg
        {
            if (trial.UI.ItemGet.IsPressed())
            {
                player.GetComponent<Player>().ChangeLimit = player.GetComponent<Player>().ChangeingTime;
                sp = other.GetComponent<SpriteRenderer>();
                col = other.GetComponent<PolygonCollider2D>();
                StartCoroutine(Reset(sp,col));
                source.PlayOneShot(audioClip);
                player.GetComponent<Player>().annimal=other.gameObject.GetComponent<ModeSetting>().animal;
                player.GetComponent<Player>().mode = other.gameObject.GetComponent<ModeSetting>().mode;
            }
        }

    }
    IEnumerator  Reset(SpriteRenderer spr ,PolygonCollider2D cold)
    {
        spr.enabled = false;
        cold.enabled = false;
        yield return new WaitForSeconds(30f);
        spr.enabled = true;
        cold.enabled = true;
    }
}
