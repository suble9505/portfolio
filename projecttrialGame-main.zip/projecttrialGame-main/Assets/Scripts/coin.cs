using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Coin : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] AudioClip audioClip;
    AudioSource source;
    void Start()
    {
        source = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    IEnumerator OnTriggerEnter2D(Collider2D collider)
    {
        if(collider.gameObject.tag=="Player"||collider.gameObject.name=="pick")
        {
            source.PlayOneShot(audioClip);
            yield return new WaitForSeconds(0.8f);
            TakaraSearch.PriceSum += 100;
            Destroy(gameObject);
        }
    }
}
