using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Threading;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{
    [SerializeField] public int minutes, seconds = 0;
    [SerializeField] GameObject minutesObj, secondsObj;
    int LimitTime;
    int Limitminutes = 0;
    int Limitseconds = 0;
    float PassTime = 0;
    int CountTime = 0;

    void Start()
    {
        LimitTime = minutes * 60 + seconds;
        if (minutes < 10)
        {
            minutesObj.GetComponent<TextMeshProUGUI>().text = "0" + minutes.ToString();
        }
        else
        {
            minutesObj.GetComponent<TextMeshProUGUI>().text = minutes.ToString();
        }
        minutesObj.GetComponent<TextMeshProUGUI>().text = minutes.ToString();

        if (seconds < 10)
        {
            secondsObj.GetComponent<TextMeshProUGUI>().text = "0" + seconds.ToString();
        }
        else
        {
            secondsObj.GetComponent<TextMeshProUGUI>().text = seconds.ToString();
        }
    }

    // Update is called once per frame
    void Update()
    {
        CountDown();
        if (CountTime <= 0)
        {
            SceneManager.LoadScene("Result");
        }
    }
    void CountDown()
    {

        PassTime += Time.deltaTime;
        CountTime = (int)(LimitTime - PassTime);

        Limitminutes = CountTime / 60;
        Limitseconds = CountTime - (Limitminutes * 60);
        //Debug.Log(PassTime);
        if (Limitminutes < 10)
        {
            minutesObj.GetComponent<TextMeshProUGUI>().text = "0" + Limitminutes.ToString();
        }
        else
        {
            minutesObj.GetComponent<TextMeshProUGUI>().text = Limitminutes.ToString();
        }
        if (Limitseconds < 10)
        {
            secondsObj.GetComponent<TextMeshProUGUI>().text = "0" + Limitseconds.ToString();
        }
        else
        {
            secondsObj.GetComponent<TextMeshProUGUI>().text = Limitseconds.ToString();
        }

    }
}
