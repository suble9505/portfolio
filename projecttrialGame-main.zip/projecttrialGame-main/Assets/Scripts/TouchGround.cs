using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Tilemaps;
using static ModeSetting;

public class TouchGround : MonoBehaviour
{
    public bool touchGround = false;
    [SerializeField] GameObject PlayerObj;
    private ProjectTrial projectTrial;
    Rigidbody2D rb;
    public bool InWater=false;
    void Start()
    {
        projectTrial = new ProjectTrial();
        projectTrial.Enable();
        rb = PlayerObj.GetComponent<Rigidbody2D>();
    }
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("floor"))
        {
            touchGround = true;
            PlayerObj.GetComponent<Player>().isjumping = false;
            if (!projectTrial.Player.Dush.IsPressed())
            {
                PlayerObj.GetComponent<Player>().realspeed = PlayerObj.GetComponent<Player>().speed;
            }
            else
            {
                PlayerObj.GetComponent<Player>().realspeed = PlayerObj.GetComponent<Player>().speed * 2;
            }
        }
    }

    public void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("floor")||collision.gameObject.CompareTag("picked"))
        {
            touchGround = false;
            if (projectTrial.Player.Dush.IsPressed())
            {
                PlayerObj.GetComponent<Player>().realspeed /= 4;
            }
            else
            {
                PlayerObj.GetComponent<Player>().realspeed /= 2;
            }
        }
    }
    public void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Water")
        {
            InWater = false;
            PlayerObj.GetComponent<Animator>().enabled = false;
            PlayerObj.GetComponent<Animator>().SetBool("InWater", false);
            rb.drag = PlayerObj.GetComponent<Player>().DefaltDrag;
            rb.gravityScale = PlayerObj.GetComponent<Player>().DefaltGlavity;
        }
    }
    public void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("floor")||collision.gameObject.CompareTag("picked"))
        {
            touchGround = true;
            if (!projectTrial.Player.Dush.IsPressed())
            {
                PlayerObj.GetComponent<Player>().realspeed = PlayerObj.GetComponent<Player>().speed;
            }
            else
            {
                PlayerObj.GetComponent<Player>().realspeed = PlayerObj.GetComponent<Player>().speed * 2;
            }
        }
        if (collision.gameObject.tag == "Water")
        {
            PlayerObj.GetComponent<Animator>().enabled = true;
            rb.drag = PlayerObj.GetComponent<Player>().waterDrag;
            InWater = true;
            PlayerObj.GetComponent<Animator>().SetBool("InWater", true);
        }
        if (collision.gameObject.tag == "Buttom Water" && PlayerObj.GetComponent<Player>().annimal == ModeSetting.Annimals.kawauso)
        {
            PlayerObj.GetComponent<Player>().rb.drag = PlayerObj.GetComponent<Player>().waterDrag;
            PlayerObj.GetComponent<Player>().rb.gravityScale = PlayerObj.GetComponent<Player>().WaterGravity;
            PlayerObj.GetComponent<Animator>().SetBool("InWater", true);
            InWater = true;
        }
    }
}
