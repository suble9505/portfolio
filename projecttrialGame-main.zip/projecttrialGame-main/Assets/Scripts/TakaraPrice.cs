using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TakaraPrice : MonoBehaviour
{
    [SerializeField] public int price;
    [SerializeField] public Difficulty difficulty;
    // Start is called before the first frame update

    public enum Difficulty
    {
        easy,normal,hard,veryhard
    }
    void Start()
    {
        int rnd=Random.Range((int)(difficulty+1)*100,(int)(difficulty+2)*100);
        price *= rnd;
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
