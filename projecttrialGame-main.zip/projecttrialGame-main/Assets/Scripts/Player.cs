using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
//using UnityEditor.Animations;
using System.Security.Cryptography;
using System.Data;
using System.Diagnostics.Tracing;
using TMPro;
using UnityEngine.UI;
using UnityEngine.Tilemaps;

public class Player : MonoBehaviour
{
    private ProjectTrial projectTrial;
    public Vector2 movement_value;
    [SerializeField] public float speed;
    [SerializeField] public float jumpPower;
    [SerializeField] Sprite[] playerSpt;
    [SerializeField] float animSpeed;
    [SerializeField] RuntimeAnimatorController[] AnimCtrl;
    [SerializeField] public float ChangeingTime;
    [SerializeField] public float DefaltDrag, waterDrag, WaterGravity, DefaltGlavity;
    [SerializeField] int moguraAddTime;
    [SerializeField] GameObject ButtomWater;
    [SerializeField] GameObject BG;
    public float ChangeLimit, ChangedTime;

    public float realspeed;
    public Rigidbody2D rb;
    public bool isjumping = false;
    private float jumptime = 0;
    GameObject Takara_price;
    public bool dush = false;
    SpriteRenderer srd;
    Animator Anim;
    [SerializeField] GameObject search;
    public bool HighJump;
    public int mode;
    public float realJumpPower;
    public bool TouchWall;
    [SerializeField] PhysicsMaterial2D physicMaterial;
    bool Changed = false;
    [SerializeField] GameObject ChangeTimeText;
    public ModeSetting.Annimals annimal = ModeSetting.Annimals.karasu;


    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        projectTrial = new ProjectTrial();
        projectTrial.Enable();
        realspeed = speed;
        srd = GetComponent<SpriteRenderer>();
        Anim = GetComponent<Animator>();
        HighJump = false;
        mode = 0;
        realJumpPower = jumpPower;
        ChangeLimit = ChangeingTime;
    }
    // Update is called once per frame
    void Update()
    {
        Touch();
        Jump();
        Move();
        Anims();
        ChangeCtrl();
    }
    void Touch()
    {
        if (search.GetComponent<TouchGround>().touchGround)
        {
            Debug.Log("������");
            Anim.SetBool("isJumping", false);
            Anim.speed = animSpeed;
            HighJump = false;
            if (annimal != ModeSetting.Annimals.rubbit)
            {
                realJumpPower = jumpPower;
            }
            Debug.Log(realspeed + "speed");
        }
    }
    void Move()
    {
        if (projectTrial.Player.Dush.WasPressedThisFrame() && isjumping == false)
        {
            realspeed = speed * 2;
            Anim.speed = animSpeed * 2;
            Debug.Log("Dush!");
        }
        if (projectTrial.Player.Dush.WasReleasedThisFrame())
        {
            realspeed = speed;
            Anim.speed = Anim.speed / 2;
            Debug.Log("!Dush");
        }
        //�ړ�
        movement_value = projectTrial.Player.Move.ReadValue<Vector2>();
        if (projectTrial.Player.Move.IsPressed())
        {
            if (movement_value.x > 0)
            {
                rb.velocity = new Vector2(realspeed, rb.velocity.y);
                srd.flipX = false;
            }
            if (movement_value.x < 0)
            {
                rb.velocity = new Vector2(-realspeed, rb.velocity.y);
                srd.flipX = true;
            }
        }
        else
        {
            if (isjumping == false)
            {
                srd.sprite = playerSpt[mode];
            }
            rb.velocity = new Vector2(rb.velocity.x * 0.97f, rb.velocity.y);
        }
        //�L�̂Ƃ�
        if (annimal == ModeSetting.Annimals.cat)
        {
            if(TouchWall)
            {
                if (projectTrial.Player.Move.IsPressed())
                {
                    if ((srd.flipX == true && movement_value.x < 0) || (srd.flipX == false && movement_value.x > 0))
                    {
                        rb.velocity = new Vector2(0, realspeed);
                    }
                    if (srd.flipX == true)
                    {
                        PZ(-90);
                    }
                    if (srd.flipX == false)
                    {
                        PZ(90);
                    }
                }
            }
            else
            {
                PZ(0);
            }
        }
    }
    void Jump()
    {
        if (!search.GetComponent<TouchGround>().InWater)
        {
            if (projectTrial.Player.Jump.IsPressed())
            {
                Anim.enabled = true;
                jumptime += Time.deltaTime;
                if (jumptime >= 0.25f && HighJump == false)
                {
                    jumptime = 0;
                    HighJump = true;
                    rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y + 2);
                }
            }
            if ((projectTrial.Player.Jump.WasPressedThisFrame()) && isjumping == false && search.GetComponent<TouchGround>().touchGround)
            {
                isjumping = true;
                Anim.enabled = true;
                rb.velocity = new Vector2(rb.velocity.x, realJumpPower);
                jumptime = 0;
                //realspeed = realspeed / 2;
                Anim.speed = Anim.speed / 2;
            }
            if (isjumping)
            {
                Anim.SetBool("isJumping", true);
            }
            if (annimal == ModeSetting.Annimals.rubbit)
            {
                realJumpPower = jumpPower + 3;
            }
        }
        else
        {
            if (projectTrial.Player.Jump.WasPerformedThisFrame())
            {
                rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y + 4);
                isjumping = true;
            }
        }
    }
    void Anims()
    {
        //�ϐg
        Anim.runtimeAnimatorController = AnimCtrl[mode];
        //�A�j���[�V����
        if (-0.1f >= rb.velocity.x || rb.velocity.x >= 0.1f || isjumping)
        {
            Anim.enabled = true;
        }
        else if (-0.1f < rb.velocity.x && rb.velocity.x < 0.1f && search.GetComponent<TouchGround>().InWater == false&&TouchWall==false)
        {
            Anim.enabled = false;
        }
    }
    public void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Wall" && annimal == ModeSetting.Annimals.cat)
        {
            TouchWall = true;
            for (int i = 0; i < 2; i++)
            {
                physicMaterial.friction = 0.4f;
            }
        }
    }
    public void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "floor")
        {
            TouchWall=false;
        }
        for (int i = 0; i < 2; i++)
        {
            physicMaterial.friction = 0;
        }
    }
    void ChangeCtrl()
    {
        Anim.runtimeAnimatorController = AnimCtrl[mode];
        if (annimal == ModeSetting.Annimals.mogura && !Changed)
        {
            ChangeLimit += moguraAddTime;
        }

        if (annimal == ModeSetting.Annimals.kawauso)
        {
            ButtomWater.GetComponent<TilemapCollider2D>().isTrigger = true;
        }
        else
        {
            ButtomWater.GetComponent<TilemapCollider2D>().isTrigger = false;
        }

        if (annimal != ModeSetting.Annimals.karasu)
        {
            Debug.Log(annimal + "!karasu");
            ChangeTimeText.GetComponent<TextMeshProUGUI>().text = ((int)ChangeLimit).ToString();
            ChangeLimit -= Time.deltaTime;
            Changed = true;
        }
        if (ChangeLimit <= 0)
        {
            annimal = ModeSetting.Annimals.karasu;
            mode = 0;
            ChangeLimit = ChangeingTime;
            Changed = false;
        }
        if (annimal == ModeSetting.Annimals.mogura && this.gameObject.GetComponent<CircleCollider2D>().enabled == true)
        {
            this.gameObject.GetComponent<CircleCollider2D>().enabled = false;
            search.transform.rotation = Quaternion.Euler(0, 0, 90);
            search.transform.position = new Vector3(search.transform.position.x + 0.15f, search.transform.position.y, 0);
        }
        else if (annimal != ModeSetting.Annimals.mogura && this.gameObject.GetComponent<CircleCollider2D>().enabled == false)
        {
            this.gameObject.GetComponent<CircleCollider2D>().enabled = true;
            search.transform.rotation = Quaternion.Euler(0, 0, 0);
            search.transform.position = new Vector3(search.transform.position.x, search.transform.position.y, 0);
        }
    }

    void PZ(float n)
    {
        transform.rotation=Quaternion.Euler(0,0,n);
    }
}
