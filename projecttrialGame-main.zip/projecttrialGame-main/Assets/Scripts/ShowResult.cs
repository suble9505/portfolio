using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShowResult : MonoBehaviour
{
    [SerializeField] GameObject[] ShowObj;
    [SerializeField] float roolspped = 0.1f;
    [SerializeField] float showspeed = 1;
    int[] nums;
    int Result = 0;
    int pResult = 0;
    Text ShowText;
    ProjectTrial projectTrial;
    bool push = false;
    int showed = -1;
    void Start()
    {
        projectTrial = new ProjectTrial();
        projectTrial.Enable();
        nums = new int[ShowObj.Length];
        Result = TakaraSearch.PriceSum;
        StartCoroutine("Rool");
        for (int i = 0; i < ShowObj.Length; i++)
        {
            nums[i] = (int)((Result - pResult) / Mathf.Pow(10, ShowObj.Length - (i + 1)));
            Debug.Log(nums[i] + "numi");
            pResult += nums[i] * (int)(Mathf.Pow(10, ShowObj.Length - (i + 1)));
            Debug.Log(pResult + "pResult");
        }
    }
    IEnumerator Rool()
    {
        for (int i = 0; i < 10; i++)
        {

            for (int j = 0; j < ShowObj.Length; j++)
            {
                if (showed < j || ShowObj[j].GetComponent<Text>().text != nums[ShowObj.Length - (j + 1)].ToString())
                {
                    ShowObj[j].GetComponent<Text>().text = i.ToString();
                }
            }

            if (i >= 9)
            {
                i = -1;
            }
            yield return new WaitForSeconds(roolspped);
        }
    }
    IEnumerator Show()
    {
        for (int i = 0; ShowObj.Length > i; i++)
        {
            ShowObj[i].GetComponent<Text>().text = nums[ShowObj.Length - (i + 1)].ToString();
            Debug.Log(ShowObj.Length - (i + 1) + "ShowObj.Length-(i+1)");
            showed = i;
            yield return new WaitForSeconds(showspeed);
        }
    }
    void Update()
    {
        if (projectTrial.UI.ItemGet.WasPressedThisFrame())
        {
            push = true;
            StartCoroutine("Show");
        }
    }
}
