using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.UIElements;

public class Picked : MonoBehaviour
{
    [SerializeField] Tilemap PickObj;
    bool pick=false;
    bool down,up=false;
    bool Right=true;
    bool Left=false;
    private ProjectTrial projectTrial;
    Vector3 picktarget;
    [SerializeField] public GameObject Player;
    [SerializeField] AnimationClip Animation;
    [SerializeField] GameObject coin;
    Player player;
    

    // Start is called before the first frame update
    void Start()
    {
        projectTrial = new ProjectTrial();
        projectTrial.Enable();
        StartCoroutine("Pick");
        player = Player.GetComponent<Player>();
    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log("movY"+player.movement_value.y);
        if (player.movement_value.y < 0 && !down)
        {
            picktarget.y -= 1;
            down = true;
        }
        else if (player.movement_value.y > 0 && !up)
        {
            picktarget.y += 0.8f;
            up = true;
        }
        else
        {
            if (down)
            {
                picktarget.y += 1f;
                down = false;
            }
            else if (up)
            {
                picktarget.y -= 0.8f;
                up = false;
            }
        }

        if (player.annimal==ModeSetting.Annimals.mogura)
        {
            if (pick&&projectTrial.UI.ItemGet.WasPressedThisFrame())
            {
                PickObj.SetTile(PickObj.WorldToCell(new Vector3(picktarget.x+0.5f,picktarget.y,0)), null);

                Debug.Log("targetPos_tile" + picktarget);
            }
        }
    }
    IEnumerator Pick()
    {
        while(true)
        {
            yield return null;
            if (player.annimal == ModeSetting.Annimals.mogura)
            {
                if (pick && projectTrial.UI.ItemGet.WasPressedThisFrame())
                {
                    Player.GetComponent<Animator>().SetBool("Pick", true);

                    yield return new WaitForSeconds(Animation.length);
                    //Instantiate(coin,picktarget,Quaternion.identity);

                    //Instantiate(coin, picktarget, Quaternion.identity);

                    PickObj.SetTile(PickObj.WorldToCell(new Vector3(picktarget.x, picktarget.y, 0)), null);

                    Debug.Log("targetPos_tile" + picktarget);
                }
                if(projectTrial.UI.ItemGet.WasReleasedThisFrame())
                {
                    Player.GetComponent<Animator>().SetBool("Pick", false);
                }
                if (Player.GetComponent<SpriteRenderer>().flipX == false && Right)
                {
                    picktarget.x += 0.8f;
                    Left = false;
                    Right =true;
                }
                else if(Player.GetComponent<SpriteRenderer>().flipX == true && Left)
                {
                    picktarget.x -= 1;
                    Left = true;
                    Right = false;
                }
            }
        }
    }

    void OnTriggerStay2D(Collider2D collision)
    {
        if(collision.gameObject.tag=="picked")
        {
            picktarget = collision.bounds.ClosestPoint(Player.transform.position);
            
            pick = true;
        }
    }
}
