using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEngine;

public class CameraMove : MonoBehaviour
{
    [SerializeField] GameObject Player;
    float dx, dy;
    private bool left,right = false;
    void Start()
    {
        dx = transform.position.x - Player.transform.position.x;
        dy = transform.position.y - Player.transform.position.y;
    }

    // Update is called once per frame
    void Update()
    {
        PY(Player.transform.position.y + dy);

        if (-7 <=Player.transform.position.x && Player.transform.position.x <= 31)
        {
            PX(Player.transform.position.x);    
        }
        if(this.CompareTag("MainCamera"))
        {
            PZ(-7);
        }
    }
    Vector3 PZ(float n)
    {
        return new Vector3(transform.position.x,transform.position.y,n);
    }
    void PX(float x)
    {
        transform.position = new Vector3(x,transform.position.y, transform.position.z);
    }
    void  PY(float y)
    {
        transform.position=new Vector3(transform.position.x,y,transform.position.z);
    }
}
