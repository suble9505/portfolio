using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModeSetting : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] public Annimals animal;
    public int mode;
    public enum Annimals
    {
        karasu, cat, rubbit, kawauso, mogura
    }
    void Start()
    {
        Annimals[] annimals = (Annimals[])Enum.GetValues(typeof(Annimals));

        for (int i = 0; i < annimals.Length; i++)
        {
            if (animal == annimals[i])
            {
                mode = i;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
